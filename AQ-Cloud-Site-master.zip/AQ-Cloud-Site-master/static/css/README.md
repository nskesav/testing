### Store CSS stylesheets here
These files can be linked in the HTML templates by the command  
`<link rel="stylesheet" href="{{url_for('static', filename='css/filename.css')}}">`  
