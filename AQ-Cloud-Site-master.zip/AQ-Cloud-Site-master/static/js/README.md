### Store JavaScript files here
These files can be linked in the HTML templates by the command  
`<script src="{{url_for('static', filename='js/filename.js')}}"></script>`  
