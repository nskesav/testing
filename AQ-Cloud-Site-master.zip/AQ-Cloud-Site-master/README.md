[![Build Status](https://travis-ci.com/srujandeshpande/AQ-Cloud-Site.svg?branch=master)](https://travis-ci.com/srujandeshpande/AQ-Cloud-Site)  
# AQ-Cloud-Site
PES Innovation Lab's Internship 2020 Project - Air Quality Cloud Site Visualization  
[Presentation Link](https://drive.google.com/file/d/1UyhHgBk02pf-diae1FCsIPtTNQCV3dE_/view?usp=sharing)

## How to run
- Intall the packages using `pip install -r requirements.txt`
- Run using `flask run`
