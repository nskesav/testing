### This contains the frontend code built using npm
Not sure if this is the best way to do it but it is ceratinly one way.

- To install: `npm install`
- To test out the code: `npm start`
- To build a distributable version `npm run build`

The code will come in the `dist` folder. This cant directly be served with flask.
